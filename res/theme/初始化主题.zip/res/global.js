$(document).ready(function(){
//网页加载入完成后执行脚本

});